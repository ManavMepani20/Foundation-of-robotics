import rclpy
from rclpy.node import Node
from open_manipulator_msgs.srv import SetJointPosition
from my_service_package.srv import FloatPos
from dynamixel_sdk_custom_interfaces.msg import SetCurrent
from dynamixel_sdk_custom_interfaces.srv import GetPosition
from std_msgs.msg import Int32
import numpy as np
import time
import asyncio
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy

class Current_ctr(Node):
    def __init__(self):
        super().__init__('Current_ctr')

        # PD controller constants
        self.kp = 0.2
        self.kd = 0.1
        self.ID = 14
        self.new_pos = None

        # Create the FloatPos service
        self.create_service(FloatPos, 'currentcalc', self.calculate_current)
        
        
        self.effort_publisher = self.create_publisher(SetCurrent, 'set_current', 10)
        self.position_subscriber = self.create_subscription(Int32, 'set_newpos', self.position_set, 10)

        self.get_position_client = self.create_client(GetPosition, "get_position")
        while not self.get_position_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for GetPosition service...')
        
        
        
    def position_set(self, msg):
        self.new_pos = msg.data
        self.get_logger().info(f"Received current positions from service: {self.new_pos}")

    def get_joint_position(self):
        """
        Send a request to get the joint position and return the position.
        """
        self.get_logger().info("Sending request to get joint position...")
        self.get_position_request = GetPosition.Request()
        self.get_position_request.id = self.ID

        future = self.get_position_client.call_async(self.get_position_request)
        
        

    def calculate_current(self, request, response):
        """
        Service callback to calculate current based on position.
        """
        self.get_logger().info(f"Received positions: {request.pos4}")

        response.success = False  # Initialize success flag

       
        target_pos = np.array(request.pos4)
        num_pos = len(target_pos)
        self.get_logger().info(f"num_pos: {num_pos}")
        while current_position is None:
            self.get_joint_position()
            current_position = self.new_pos
        
        for i in range(num_pos):
            target_pos = target_pos[i]
            self.get_logger().info(f"Received target positions: {target_pos}")

            # Get the current position using the get_joint_position method
            while current_position is None:
                self.get_joint_position()
                current_position = self.new_pos

            self.get_logger().info(f"Received current positions: {current_position}")
            if current_position is None:
                continue  # Skip if the position couldn't be retrieved

            # Compute control signal and publish current
            diff = abs(target_pos - current_position)
            self.get_logger().info(f"diff: {diff}")
            previous_position = current_position
            previous_time = self.get_clock().now().to_msg()

            
            while diff > 30:
                current_time = self.get_clock().now().to_msg()
                self.get_joint_position()
                current_position = self.new_pos
                self.get_logger().info(f"Received current positions: {current_position}")
                if current_position is None:
                    break  # Exit the loop if the position couldn't be retrieved
                dt = (current_time.sec - previous_time.sec) + (current_time.nanosec - previous_time.nanosec) * 1e-9

                self.get_logger().info(f"dt: {dt}")

                # Position error and derivative of error
                error = target_pos - current_position
                error_derivative = (current_position - previous_position) / dt if dt > 0 else 0.0

                # PD control law
                effort = self.kp * error - self.kd * error_derivative
                effort = -int(effort)

                # Publish effort
                current_msg = SetCurrent()
                current_msg.id = self.ID
                current_msg.current = effort
                self.effort_publisher.publish(current_msg)

                # Log and update states
                self.get_logger().info(f"Effort: {effort}, Position: {current_position}, Error: {error}")
                previous_position = current_position
                previous_time = current_time
                diff = abs(target_pos - current_position)

        response.success = True  # Set success to True if everything went fine
        self.get_logger().info(f"Returning success: {response.success}")
        return response


def main():
    rclpy.init()
    node = Current_ctr()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
